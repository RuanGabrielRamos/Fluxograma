let campoIdade;
let campoFantasia;

function setup() {
    createCanvas(600, 600);
    campoIdade = createInput("15");
    campoFantasia = createCheckbox("Gosta de Ficção Científica?");
}

function draw() {
    background(220);
    
    // Desenhar o fluxograma
    drawFlowchart();
    
    // Lógica para recomendar filme
    let idade = campoIdade.value();
    let gostaDeFiccao = campoFantasia.checked();
    let recomendacao = geraRecomendacao(idade, gostaDeFiccao);
    
    // Exibir a recomendação
    textSize(16);
    fill(0);
    textAlign(CENTER);
    text(recomendacao, width / 2, height - 30);
}

function drawFlowchart() {
    textSize(16);
    fill(0);
    
    // Início
    rect(200, 50, 200, 50);
    textAlign(CENTER);
    text("Início", 300, 80);
    
    // Pergunta: Idade >= 10?
    rect(200, 150, 200, 50);
    text("Idade >= 10?", 300, 180);
    
    // Setas
    line(300, 100, 300, 150); // seta para baixo
    line(300, 200, 300, 250); // seta para baixo
    
    // Se sim
    rect(200, 250, 200, 50);
    text("Gosta de Ficção Científica?", 300, 280);
    
    // Setas
    line(300, 200, 300, 250); // seta para baixo
    line(300, 300, 300, 350); // seta para baixo
    
    // Se sim (gosta de ficção científica)
    rect(200, 350, 200, 50);
    text("Interestllar", 300, 380);

    // Se não (não gosta de ficção científica)
    line(400, 280, 500, 280); // seta para direita
    rect(400, 250, 200, 50);
    text("Idade >=14?", 500, 280);

    // Setas
    line(500, 300, 500, 350); // seta para baixo
    
    // Se sim (idade >=14)
    rect(400,350 ,200 ,50)
     text("A Espera por um Milagre",500 ,380);

     // Se não (idade <14)
     line(500 ,380 ,500 ,430); 
     rect(400 ,430 ,200 ,50)
     text("Blade Runner 2049",500 ,460);

     // Se não (idade <10)
     line(300 ,430 ,300 ,480); 
     rect(200 ,480 ,200 ,50)
     text("Pardo Estudiosos",300 ,510)

     line(400 ,510 ,600 ,510); 
     rect(600 ,480 ,200 ,50)
     text("Napoleão",700 ,510)

}

function geraRecomendacao(idade,gostaDeFiccao) {
   if (idade >=10) {
       if (gostaDeFiccao) {
           return "Interestllar";
       } else {
           if (idade >=14) {
               return "A Espera por um Milagre";
           } else {
               return "Blade Runner 2049";
           }
       }
   } else {
       return "Pardo Estudiosos";
   }
}